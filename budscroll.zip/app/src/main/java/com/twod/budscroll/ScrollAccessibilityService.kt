package com.twod.budscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class ScrollAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScrollAccessibilityService? = null

        fun swipe(up: Boolean): Boolean = instance?.doSwipe(up) ?: false
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private fun doSwipe(up: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val top = dm.heightPixels * 0.30f
        val bottom = dm.heightPixels * 0.75f
        val path = Path().apply {
            if (up) {
                moveTo(x, bottom)
                lineTo(x, top)
            } else {
                moveTo(x, top)
                lineTo(x, bottom)
            }
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 180))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}
