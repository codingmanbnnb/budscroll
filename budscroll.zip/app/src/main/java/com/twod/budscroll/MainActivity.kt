package com.twod.budscroll

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(s: String, size: Float) = TextView(this).apply {
            text = s
            textSize = size
            setPadding(0, 0, 0, pad / 2)
        }

        fun button(s: String, onClick: () -> Unit) = Button(this).apply {
            text = s
            setOnClickListener { onClick() }
        }

        root.addView(label("BudScroll", 28f))
        root.addView(label("Double pinch = swipe up (next reel).\nTriple pinch = swipe down (previous).", 16f))
        status = label("", 15f)
        root.addView(status)
        root.addView(button("1. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        toggle = button("2. Start buds control") { toggleService() }
        root.addView(toggle)
        root.addView(button("3. Battery / background settings") { openBattery() })
        root.addView(button("Test swipe up (in 3 sec)") {
            Handler(Looper.getMainLooper()).postDelayed({ ScrollAccessibilityService.swipe(true) }, 3000)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val a11y = ScrollAccessibilityService.instance != null
        val svc = BudsService.running
        status.text = "Accessibility: " + (if (a11y) "ON" else "OFF") +
            "\nBuds control: " + (if (svc) "ON" else "OFF")
        toggle.text = if (svc) "2. Stop buds control" else "2. Start buds control"
    }

    private fun toggleService() {
        val i = Intent(this, BudsService::class.java)
        if (BudsService.running) stopService(i) else startForegroundService(i)
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 600)
    }

    private fun openBattery() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
    }
}
