package com.twod.budscroll

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.SystemClock

class BudsService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL_ID = "buds"
    }

    private var session: MediaSession? = null
    private var track: AudioTrack? = null
    private var lastAction = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (session == null) {
            setupSession()
            startSilence()
        }
        running = true
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Buds control", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("BudScroll is on")
            .setContentText("Double pinch = swipe up, triple pinch = swipe down")
            .setSmallIcon(android.R.drawable.ic_media_next)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, notification)
        }
    }

    private fun setupSession() {
        val s = MediaSession(this, "BudScroll")
        @Suppress("DEPRECATION")
        s.setFlags(
            MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS
        )
        s.setCallback(object : MediaSession.Callback() {
            override fun onSkipToNext() {
                trigger(true)
            }

            override fun onSkipToPrevious() {
                trigger(false)
            }

            // Single pinch (play/pause) is ignored; keep session "playing" so it keeps the buttons.
            override fun onPlay() {
                markPlaying()
            }

            override fun onPause() {
                markPlaying()
            }
        })
        session = s
        markPlaying()
        s.isActive = true
    }

    private fun markPlaying() {
        val state = PlaybackState.Builder()
            .setActions(
                PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                    PlaybackState.ACTION_PLAY_PAUSE or
                    PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS
            )
            .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
            .build()
        session?.setPlaybackState(state)
    }

    private fun trigger(up: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastAction < 250) return
        lastAction = now
        ScrollAccessibilityService.swipe(up)
    }

    // Looping silent audio makes Android treat this as the active media app.
    private fun startSilence() {
        val sampleRate = 8000
        val bytes = sampleRate * 2 // 1 second, mono, 16-bit
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(ByteArray(bytes), 0, bytes)
        t.setLoopPoints(0, sampleRate, -1)
        t.play()
        track = t
    }

    override fun onDestroy() {
        running = false
        track?.release()
        track = null
        session?.release()
        session = null
        super.onDestroy()
    }
}
